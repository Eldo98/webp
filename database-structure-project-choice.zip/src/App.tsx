import { useState, useEffect } from 'react';
import {
  Users,
  Briefcase,
  Calendar,
  Settings,
  LogOut,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  CheckCircle,
  Clock,
  MapPin,
  Phone,
  Mail,
  User,
  Shield,
  Building2,
  FolderKanban,
  LayoutDashboard,
  Bell,
  Menu,
  X,
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Camera,
  FileText,
  ListTodo,
  Grid3X3,
  Table as TableIcon,
  PieChart,
  AlertCircle
} from 'lucide-react';
import { cn } from './utils/cn';

// Types
interface UserData {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  placeOfBirth: string;
  residence: string;
  email: string;
  phone: string;
  username: string;
  password: string;
  role: 'admin' | 'user';
  department: string;
  status: 'active' | 'inactive' | 'on_leave';
  position: string;
  joinDate: string;
  bio: string;
  avatar: string;
  permissions: Permission[];
  coverImage: string;
  posts: Post[];
  followers: string[];
  following: string[];
}

interface Permission {
  id: string;
  name: string;
  enabled: boolean;
}

interface Post {
  id: string;
  content: string;
  image?: string;
  likes: number;
  comments: Comment[];
  timestamp: string;
  likedBy: string[];
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: string;
}

interface Project {
  id: string;
  name: string;
  description: string;
  status: 'planning' | 'in_progress' | 'completed' | 'on_hold';
  startDate: string;
  endDate: string;
  assignedUsers: string[];
  tasks: Task[];
  progress: number;
  priority: 'low' | 'medium' | 'high';
}

interface Task {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'in_progress' | 'done';
  assignedTo: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
}

interface NewsItem {
  id: string;
  title: string;
  content: string;
  image?: string;
  authorId: string;
  authorName: string;
  timestamp: string;
  likes: number;
  comments: number;
  likedBy: string[];
}

interface Department {
  id: string;
  name: string;
  description: string;
  color: string;
  memberCount: number;
}

// Default data
const DEFAULT_PERMISSIONS: Permission[] = [
  { id: 'view_projects', name: 'Pregled projekata', enabled: true },
  { id: 'edit_projects', name: 'Uređivanje projekata', enabled: false },
  { id: 'delete_projects', name: 'Brisanje projekata', enabled: false },
  { id: 'view_users', name: 'Pregled korisnika', enabled: true },
  { id: 'edit_users', name: 'Uređivanje korisnika', enabled: false },
  { id: 'manage_tasks', name: 'Upravljanje zadacima', enabled: false },
  { id: 'post_news', name: 'Objavljivanje novosti', enabled: false },
  { id: 'view_analytics', name: 'Pregled analitike', enabled: false },
  { id: 'admin_panel', name: 'Pristup admin panelu', enabled: false },
];

const DEPARTMENTS: Department[] = [
  { id: 'it', name: 'IT Odjel', description: 'Razvoj softvera i infrastruktura', color: 'bg-blue-500', memberCount: 0 },
  { id: 'production', name: 'Proizvodnja', description: 'Proizvodni proces i kvaliteta', color: 'bg-green-500', memberCount: 0 },
  { id: 'sales', name: 'Prodaja', description: 'Prodaja i marketing', color: 'bg-orange-500', memberCount: 0 },
  { id: 'hr', name: 'Ljudski resursi', description: 'Zapošljavanje i razvoj', color: 'bg-pink-500', memberCount: 0 },
  { id: 'finance', name: 'Financije', description: 'Računovodstvo i financije', color: 'bg-purple-500', memberCount: 0 },
  { id: 'operations', name: 'Operacije', description: 'Operativni menadžment', color: 'bg-cyan-500', memberCount: 0 },
];

// Storage helpers
const storage = {
  getUsers: (): UserData[] => {
    const data = localStorage.getItem('company_users');
    return data ? JSON.parse(data) : [];
  },
  setUsers: (users: UserData[]) => localStorage.setItem('company_users', JSON.stringify(users)),
  getProjects: (): Project[] => {
    const data = localStorage.getItem('company_projects');
    return data ? JSON.parse(data) : [];
  },
  setProjects: (projects: Project[]) => localStorage.setItem('company_projects', JSON.stringify(projects)),
  getNews: (): NewsItem[] => {
    const data = localStorage.getItem('company_news');
    return data ? JSON.parse(data) : [];
  },
  setNews: (news: NewsItem[]) => localStorage.setItem('company_news', JSON.stringify(news)),
  getCurrentUser: (): UserData | null => {
    const data = localStorage.getItem('current_user');
    return data ? JSON.parse(data) : null;
  },
  setCurrentUser: (user: UserData | null) => {
    if (user) {
      localStorage.setItem('current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('current_user');
    }
  },
};

// Generate avatar URL
const generateAvatar = (name: string) => {
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&color=fff&size=128`;
};

// Generate cover image
const generateCover = () => {
  return `https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800&q=80`;
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);
  const [users, setUsers] = useState<UserData[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [view, setView] = useState<'login' | 'admin' | 'dashboard' | 'profile' | 'projects' | 'news' | 'users' | 'settings'>('login');
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');

  // Initialize data
  useEffect(() => {
    const savedUsers = storage.getUsers();
    const savedProjects = storage.getProjects();
    const savedNews = storage.getNews();
    const savedCurrentUser = storage.getCurrentUser();

    if (savedUsers.length === 0) {
      // Create default admin
      const adminUser: UserData = {
        id: 'admin-1',
        firstName: 'Administrator',
        lastName: 'Sustava',
        dateOfBirth: '1990-01-01',
        placeOfBirth: 'Zagreb',
        residence: 'Zagreb',
        email: 'admin@firma.hr',
        phone: '+385 99 123 4567',
        username: 'admin',
        password: 'admin123',
        role: 'admin',
        department: 'it',
        status: 'active',
        position: 'Administrator',
        joinDate: new Date().toISOString().split('T')[0],
        bio: 'Glavni administrator sustava.',
        avatar: generateAvatar('Administrator Sustava'),
        coverImage: generateCover(),
        permissions: DEFAULT_PERMISSIONS.map(p => ({ ...p, enabled: true })),
        posts: [],
        followers: [],
        following: [],
      };
      storage.setUsers([adminUser]);
      setUsers([adminUser]);
    } else {
      setUsers(savedUsers);
    }

    if (savedProjects.length === 0) {
      const defaultProjects: Project[] = [
        {
          id: 'proj-1',
          name: 'Web Aplikacija',
          description: 'Razvoj nove web aplikacije za klijenta',
          status: 'in_progress',
          startDate: '2024-01-01',
          endDate: '2024-06-30',
          assignedUsers: [],
          tasks: [
            { id: 'task-1', title: 'Dizajn', description: 'UI/UX dizajn', status: 'done', assignedTo: '', dueDate: '2024-02-01', priority: 'high' },
            { id: 'task-2', title: 'Backend', description: 'API razvoj', status: 'in_progress', assignedTo: '', dueDate: '2024-04-01', priority: 'high' },
          ],
          progress: 45,
          priority: 'high',
        },
      ];
      storage.setProjects(defaultProjects);
      setProjects(defaultProjects);
    } else {
      setProjects(savedProjects);
    }

    if (savedNews.length === 0) {
      const defaultNews: NewsItem[] = [
        {
          id: 'news-1',
          title: 'Dobrodošli u našu firmu!',
          content: 'Ovo je vaša nova interna platforma za komunikaciju i suradnju. Sretno rad!',
          authorId: 'admin-1',
          authorName: 'Administrator Sustava',
          timestamp: new Date().toISOString(),
          likes: 0,
          comments: 0,
          likedBy: [],
        },
      ];
      storage.setNews(defaultNews);
      setNews(defaultNews);
    } else {
      setNews(savedNews);
    }

    if (savedCurrentUser) {
      setCurrentUser(savedCurrentUser);
      setView(savedCurrentUser.role === 'admin' ? 'admin' : 'dashboard');
    }
  }, []);

  // Login handler
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const allUsers = storage.getUsers();
    const user = allUsers.find(u => u.username === loginForm.username && u.password === loginForm.password);
    
    if (user) {
      setCurrentUser(user);
      storage.setCurrentUser(user);
      setView(user.role === 'admin' ? 'admin' : 'dashboard');
      setLoginError('');
    } else {
      setLoginError('Pogrešno korisničko ime ili lozinka');
    }
  };

  // Logout handler
  const handleLogout = () => {
    setCurrentUser(null);
    storage.setCurrentUser(null);
    setView('login');
    setLoginForm({ username: '', password: '' });
  };

  // Update data handlers
  const updateUsers = (newUsers: UserData[]) => {
    setUsers(newUsers);
    storage.setUsers(newUsers);
  };

  const updateProjects = (newProjects: Project[]) => {
    setProjects(newProjects);
    storage.setProjects(newProjects);
  };

  const updateNews = (newNews: NewsItem[]) => {
    setNews(newNews);
    storage.setNews(newNews);
  };

  // Login View
  if (view === 'login') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">FirmaConnect</h1>
            <p className="text-gray-500 mt-2">Interna platforma za suradnju</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Korisničko ime</label>
              <input
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
                placeholder="Unesite korisničko ime"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Lozinka</label>
              <input
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
                placeholder="Unesite lozinku"
              />
            </div>
            {loginError && (
              <div className="bg-red-50 text-red-600 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {loginError}
              </div>
            )}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg hover:scale-[1.02] transition-all"
            >
              Prijava
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-500">
            <p>Demo podaci:</p>
            <p className="font-mono bg-gray-100 px-2 py-1 rounded mt-1">admin / admin123</p>
          </div>
        </div>
      </div>
    );
  }

  // Main App Layout
  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside
        className={cn(
          "bg-white border-r border-gray-200 transition-all duration-300 fixed h-full z-20",
          sidebarOpen ? "w-64" : "w-20"
        )}
      >
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            {sidebarOpen && (
              <div>
                <h1 className="font-bold text-gray-900">FirmaConnect</h1>
                <p className="text-xs text-gray-500">{currentUser?.role === 'admin' ? 'Admin Panel' : 'Dashboard'}</p>
              </div>
            )}
          </div>
        </div>

        <nav className="p-3 space-y-1">
          {currentUser?.role === 'admin' && (
            <SidebarItem
              icon={<Shield className="w-5 h-5" />}
              label="Admin Panel"
              active={view === 'admin'}
              onClick={() => setView('admin')}
              collapsed={!sidebarOpen}
            />
          )}
          <SidebarItem
            icon={<LayoutDashboard className="w-5 h-5" />}
            label="Dashboard"
            active={view === 'dashboard'}
            onClick={() => setView('dashboard')}
            collapsed={!sidebarOpen}
          />
          <SidebarItem
            icon={<User className="w-5 h-5" />}
            label="Moj Profil"
            active={view === 'profile'}
            onClick={() => { setSelectedUser(currentUser); setView('profile'); }}
            collapsed={!sidebarOpen}
          />
          <SidebarItem
            icon={<FolderKanban className="w-5 h-5" />}
            label="Projekti"
            active={view === 'projects'}
            onClick={() => setView('projects')}
            collapsed={!sidebarOpen}
          />
          <SidebarItem
            icon={<Bell className="w-5 h-5" />}
            label="Novosti"
            active={view === 'news'}
            onClick={() => setView('news')}
            collapsed={!sidebarOpen}
          />
          {(currentUser?.role === 'admin' || currentUser?.permissions?.find(p => p.id === 'view_users')?.enabled) && (
            <SidebarItem
              icon={<Users className="w-5 h-5" />}
              label="Zaposlenici"
              active={view === 'users'}
              onClick={() => setView('users')}
              collapsed={!sidebarOpen}
            />
          )}
          <SidebarItem
            icon={<Settings className="w-5 h-5" />}
            label="Postavke"
            active={view === 'settings'}
            onClick={() => setView('settings')}
            collapsed={!sidebarOpen}
          />
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-gray-200">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-3 py-2 rounded-xl text-red-600 hover:bg-red-50 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            {sidebarOpen && <span className="font-medium">Odjava</span>}
          </button>
        </div>

        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -right-3 top-20 w-6 h-6 bg-white border border-gray-200 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-600 shadow-sm"
        >
          {sidebarOpen ? <X className="w-3 h-3" /> : <Menu className="w-3 h-3" />}
        </button>
      </aside>

      {/* Main Content */}
      <main className={cn("flex-1 transition-all duration-300", sidebarOpen ? "ml-64" : "ml-20")}>
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">
              {view === 'admin' && 'Admin Panel'}
              {view === 'dashboard' && 'Dashboard'}
              {view === 'profile' && 'Profil'}
              {view === 'projects' && 'Projekti'}
              {view === 'news' && 'Novosti'}
              {view === 'users' && 'Zaposlenici'}
              {view === 'settings' && 'Postavke'}
            </h2>
            <div className="flex items-center gap-4">
              <button className="relative p-2 text-gray-400 hover:text-gray-600">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <div className="flex items-center gap-3">
                <img
                  src={currentUser?.avatar}
                  alt={currentUser?.firstName}
                  className="w-10 h-10 rounded-full object-cover border-2 border-indigo-100"
                />
                <div className="hidden md:block">
                  <p className="font-medium text-gray-900">{currentUser?.firstName} {currentUser?.lastName}</p>
                  <p className="text-xs text-gray-500">{DEPARTMENTS.find(d => d.id === currentUser?.department)?.name}</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="p-6">
          {view === 'admin' && currentUser?.role === 'admin' && (
            <AdminPanel
              users={users}
              projects={projects}
              news={news}
              onUpdateUsers={updateUsers}
              onUpdateProjects={updateProjects}
              onUpdateNews={updateNews}
              onViewUser={(user) => { setSelectedUser(user); setView('profile'); }}
              currentUser={currentUser}
            />
          )}
          {view === 'dashboard' && (
            <Dashboard
              user={currentUser!}
              users={users}
              projects={projects}
              news={news}
              onViewUser={(user) => { setSelectedUser(user); setView('profile'); }}
              onUpdateNews={updateNews}
            />
          )}
          {view === 'profile' && selectedUser && (
            <ProfileView
              user={selectedUser}
              currentUser={currentUser!}
              allUsers={users}
              onUpdateUser={(updatedUser) => {
                const newUsers = users.map(u => u.id === updatedUser.id ? updatedUser : u);
                updateUsers(newUsers);
                if (currentUser?.id === updatedUser.id) {
                  setCurrentUser(updatedUser);
                  storage.setCurrentUser(updatedUser);
                }
              }}
              isAdmin={currentUser?.role === 'admin'}
            />
          )}
          {view === 'projects' && (
            <ProjectsView
              projects={projects}
              users={users}
              currentUser={currentUser!}
              onUpdateProjects={updateProjects}
            />
          )}
          {view === 'news' && (
            <NewsView
              news={news}
              users={users}
              currentUser={currentUser!}
              onUpdateNews={updateNews}
            />
          )}
          {view === 'users' && (
            <UsersView
              users={users}
              onViewUser={(user) => { setSelectedUser(user); setView('profile'); }}
            />
          )}
          {view === 'settings' && (
            <SettingsView
              user={currentUser!}
              onUpdateUser={(updatedUser) => {
                const newUsers = users.map(u => u.id === updatedUser.id ? updatedUser : u);
                updateUsers(newUsers);
                setCurrentUser(updatedUser);
                storage.setCurrentUser(updatedUser);
              }}
            />
          )}
        </div>
      </main>
    </div>
  );
}

// Sidebar Item Component
function SidebarItem({ icon, label, active, onClick, collapsed }: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
  collapsed: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 w-full px-3 py-2.5 rounded-xl transition-all",
        active
          ? "bg-indigo-50 text-indigo-600"
          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
      )}
    >
      {icon}
      {!collapsed && <span className="font-medium">{label}</span>}
    </button>
  );
}

// Admin Panel Component
function AdminPanel({ users, projects, news, onUpdateUsers, onUpdateProjects, onUpdateNews, onViewUser, currentUser }: {
  users: UserData[];
  projects: Project[];
  news: NewsItem[];
  onUpdateUsers: (users: UserData[]) => void;
  onUpdateProjects: (projects: Project[]) => void;
  onUpdateNews: (news: NewsItem[]) => void;
  onViewUser: (user: UserData) => void;
  currentUser: UserData;
}) {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'projects' | 'news'>('overview');
  const [showUserForm, setShowUserForm] = useState(false);
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [showNewsForm, setShowNewsForm] = useState(false);
  const [editingUser, setEditingUser] = useState<UserData | null>(null);

  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.status === 'active').length,
    totalProjects: projects.length,
    activeProjects: projects.filter(p => p.status === 'in_progress').length,
    completedProjects: projects.filter(p => p.status === 'completed').length,
    totalNews: news.length,
  };

  const departmentStats = DEPARTMENTS.map(dept => ({
    ...dept,
    count: users.filter(u => u.department === dept.id).length,
  }));

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex gap-2 bg-white p-1 rounded-xl border border-gray-200 w-fit">
        {[
          { id: 'overview', label: 'Pregled', icon: LayoutDashboard },
          { id: 'users', label: 'Korisnici', icon: Users },
          { id: 'projects', label: 'Projekti', icon: FolderKanban },
          { id: 'news', label: 'Novosti', icon: Bell },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all",
              activeTab === tab.id
                ? "bg-indigo-600 text-white"
                : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Ukupno zaposlenika"
              value={stats.totalUsers}
              subtitle={`${stats.activeUsers} aktivnih`}
              icon={<Users className="w-6 h-6" />}
              color="bg-blue-500"
            />
            <StatCard
              title="Aktivni projekti"
              value={stats.activeProjects}
              subtitle={`od ${stats.totalProjects} ukupno`}
              icon={<FolderKanban className="w-6 h-6" />}
              color="bg-green-500"
            />
            <StatCard
              title="Završeni projekti"
              value={stats.completedProjects}
              subtitle="uspješno realizirani"
              icon={<CheckCircle className="w-6 h-6" />}
              color="bg-purple-500"
            />
            <StatCard
              title="Novosti"
              value={stats.totalNews}
              subtitle="objava na ploči"
              icon={<Bell className="w-6 h-6" />}
              color="bg-orange-500"
            />
          </div>

          {/* Department Distribution */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Raspodjela po odjelima</h3>
              <div className="space-y-3">
                {departmentStats.map((dept) => (
                  <div key={dept.id} className="flex items-center gap-4">
                    <div className={cn("w-3 h-3 rounded-full", dept.color)}></div>
                    <span className="flex-1 text-gray-700">{dept.name}</span>
                    <span className="font-semibold text-gray-900">{dept.count}</span>
                    <div className="w-32 h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={cn("h-full rounded-full", dept.color)}
                        style={{ width: `${(dept.count / Math.max(stats.totalUsers, 1)) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Status zaposlenika</h3>
              <div className="space-y-4">
                {[
                  { label: 'Aktivni', count: users.filter(u => u.status === 'active').length, color: 'bg-green-500' },
                  { label: 'Na odsustvu', count: users.filter(u => u.status === 'on_leave').length, color: 'bg-yellow-500' },
                  { label: 'Neaktivni', count: users.filter(u => u.status === 'inactive').length, color: 'bg-gray-400' },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-3 h-3 rounded-full", item.color)}></div>
                      <span className="text-gray-700">{item.label}</span>
                    </div>
                    <span className="font-bold text-gray-900">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Nedavne aktivnosti</h3>
            <div className="space-y-3">
              {news.slice(0, 5).map((item) => (
                <div key={item.id} className="flex items-center gap-4 p-3 hover:bg-gray-50 rounded-xl transition-colors">
                  <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                    <Bell className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{item.title}</p>
                    <p className="text-sm text-gray-500">{item.authorName} • {new Date(item.timestamp).toLocaleDateString('hr-HR')}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="relative">
              <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Pretraži zaposlenike..."
                className="pl-10 pr-4 py-2 border border-gray-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none w-64"
              />
            </div>
            <button
              onClick={() => { setEditingUser(null); setShowUserForm(true); }}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Dodaj zaposlenika
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Zaposlenik</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Odjel</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Email</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Akcije</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {users.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img src={user.avatar} alt={user.firstName} className="w-10 h-10 rounded-full object-cover" />
                        <div>
                          <p className="font-medium text-gray-900">{user.firstName} {user.lastName}</p>
                          <p className="text-sm text-gray-500">{user.position}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-gray-100 rounded-lg text-sm text-gray-700">
                        {DEPARTMENTS.find(d => d.id === user.department)?.name}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={user.status} />
                    </td>
                    <td className="py-3 px-4 text-gray-600">{user.email}</td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => onViewUser(user)}
                          className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => { setEditingUser(user); setShowUserForm(true); }}
                          className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {user.id !== currentUser.id && (
                          <button
                            onClick={() => {
                              if (confirm('Jeste li sigurni da želite obrisati ovog korisnika?')) {
                                onUpdateUsers(users.filter(u => u.id !== user.id));
                              }
                            }}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Projects Tab */}
      {activeTab === 'projects' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-semibold text-gray-900">Upravljanje projektima</h3>
            <button
              onClick={() => setShowProjectForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Novi projekt
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.map((project) => (
              <div key={project.id} className="bg-white rounded-2xl border border-gray-200 p-5">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-semibold text-gray-900">{project.name}</h4>
                    <p className="text-sm text-gray-500 mt-1">{project.description}</p>
                  </div>
                  <ProjectStatusBadge status={project.status} />
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Napredak</span>
                    <span className="font-medium text-gray-900">{project.progress}%</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-500 rounded-full transition-all"
                      style={{ width: `${project.progress}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Zadaci</span>
                    <span className="font-medium text-gray-900">{project.tasks.filter(t => t.status === 'done').length}/{project.tasks.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Prioritet</span>
                    <PriorityBadge priority={project.priority} />
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100 flex gap-2">
                  <button className="flex-1 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                    Uredi
                  </button>
                  <button
                    onClick={() => {
                      if (confirm('Jeste li sigurni?')) {
                        onUpdateProjects(projects.filter(p => p.id !== project.id));
                      }
                    }}
                    className="flex-1 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    Obriši
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* News Tab */}
      {activeTab === 'news' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-semibold text-gray-900">Upravljanje novostima</h3>
            <button
              onClick={() => setShowNewsForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nova objava
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {news.map((item) => (
              <div key={item.id} className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                {item.image && (
                  <img src={item.image} alt={item.title} className="w-full h-48 object-cover" />
                )}
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="px-2 py-1 bg-indigo-100 text-indigo-700 text-xs font-medium rounded-lg">
                      {item.authorName}
                    </span>
                    <span className="text-gray-400 text-sm">
                      {new Date(item.timestamp).toLocaleDateString('hr-HR')}
                    </span>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">{item.content}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" /> {item.likes}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" /> {item.comments}
                    </span>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-100 flex gap-2">
                    <button
                      onClick={() => {
                        if (confirm('Jeste li sigurni?')) {
                          onUpdateNews(news.filter(n => n.id !== item.id));
                        }
                      }}
                      className="flex-1 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      Obriši
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* User Form Modal */}
      {showUserForm && (
        <UserFormModal
          user={editingUser}
          onClose={() => { setShowUserForm(false); setEditingUser(null); }}
          onSave={(userData) => {
            if (editingUser) {
              onUpdateUsers(users.map(u => u.id === editingUser.id ? { ...u, ...userData } : u));
            } else {
              const newUser: UserData = {
                id: `user-${Date.now()}`,
                firstName: userData.firstName || '',
                lastName: userData.lastName || '',
                dateOfBirth: userData.dateOfBirth || '',
                placeOfBirth: userData.placeOfBirth || '',
                residence: userData.residence || '',
                email: userData.email || '',
                phone: userData.phone || '',
                username: userData.username || '',
                password: userData.password || '',
                role: userData.role || 'user',
                department: userData.department || 'it',
                status: userData.status || 'active',
                position: userData.position || '',
                bio: userData.bio || '',
                avatar: generateAvatar(`${userData.firstName || ''} ${userData.lastName || ''}`),
                coverImage: generateCover(),
                joinDate: new Date().toISOString().split('T')[0],
                posts: [],
                followers: [],
                following: [],
                permissions: DEFAULT_PERMISSIONS,
              };
              onUpdateUsers([...users, newUser]);
            }
            setShowUserForm(false);
            setEditingUser(null);
          }}
          departments={DEPARTMENTS}
        />
      )}

      {/* Project Form Modal */}
      {showProjectForm && (
        <ProjectFormModal
          onClose={() => setShowProjectForm(false)}
          onSave={(projectData) => {
            const newProject: Project = {
              id: `proj-${Date.now()}`,
              name: projectData.name || '',
              description: projectData.description || '',
              status: projectData.status || 'planning',
              startDate: projectData.startDate || '',
              endDate: projectData.endDate || '',
              priority: projectData.priority || 'medium',
              assignedUsers: projectData.assignedUsers || [],
              tasks: [],
              progress: 0,
            };
            onUpdateProjects([...projects, newProject]);
            setShowProjectForm(false);
          }}
        />
      )}

      {/* News Form Modal */}
      {showNewsForm && (
        <NewsFormModal
          onClose={() => setShowNewsForm(false)}
          onSave={(newsData) => {
            const newNews: NewsItem = {
              id: `news-${Date.now()}`,
              title: newsData.title || '',
              content: newsData.content || '',
              image: newsData.image,
              authorId: currentUser.id,
              authorName: `${currentUser.firstName} ${currentUser.lastName}`,
              timestamp: new Date().toISOString(),
              likes: 0,
              comments: 0,
              likedBy: [],
            };
            onUpdateNews([newNews, ...news]);
            setShowNewsForm(false);
          }}
        />
      )}
    </div>
  );
}

// User Form Modal
function UserFormModal({ user, onClose, onSave, departments }: {
  user: UserData | null;
  onClose: () => void;
  onSave: (data: Partial<UserData>) => void;
  departments: Department[];
}) {
  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    dateOfBirth: user?.dateOfBirth || '',
    placeOfBirth: user?.placeOfBirth || '',
    residence: user?.residence || '',
    email: user?.email || '',
    phone: user?.phone || '',
    username: user?.username || '',
    password: user?.password || '',
    role: user?.role || 'user',
    department: user?.department || departments[0].id,
    status: user?.status || 'active',
    position: user?.position || '',
    bio: user?.bio || '',
    permissions: user?.permissions || DEFAULT_PERMISSIONS,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const togglePermission = (permId: string) => {
    setFormData({
      ...formData,
      permissions: formData.permissions.map(p =>
        p.id === permId ? { ...p, enabled: !p.enabled } : p
      ),
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h3 className="text-xl font-bold text-gray-900">
            {user ? 'Uredi zaposlenika' : 'Novi zaposlenik'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[70vh]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Personal Info */}
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                <User className="w-4 h-4" /> Osobni podaci
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Ime</label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Prezime</label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Datum rođenja</label>
                <input
                  type="date"
                  required
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mjesto rođenja</label>
                <input
                  type="text"
                  required
                  value={formData.placeOfBirth}
                  onChange={(e) => setFormData({ ...formData, placeOfBirth: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mjesto bivališta</label>
                <input
                  type="text"
                  required
                  value={formData.residence}
                  onChange={(e) => setFormData({ ...formData, residence: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
            </div>

            {/* Work Info */}
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                <Briefcase className="w-4 h-4" /> Poslovni podaci
              </h4>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Broj telefona</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Korisničko ime</label>
                <input
                  type="text"
                  required
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Lozinka</label>
                <input
                  type="password"
                  required={!user}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Odjel</label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                  >
                    {departments.map((dept) => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                  >
                    <option value="active">Aktivan</option>
                    <option value="inactive">Neaktivan</option>
                    <option value="on_leave">Na odsustvu</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pozicija</label>
                <input
                  type="text"
                  value={formData.position}
                  onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Permissions */}
          <div className="mt-6">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2 mb-4">
              <Shield className="w-4 h-4" /> Dozvole
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {formData.permissions.map((perm) => (
                <label
                  key={perm.id}
                  className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  <input
                    type="checkbox"
                    checked={perm.enabled}
                    onChange={() => togglePermission(perm.id)}
                    className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                  />
                  <span className="text-sm text-gray-700">{perm.name}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="mt-6 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 border border-gray-200 rounded-xl font-medium hover:bg-gray-50 transition-colors"
            >
              Odustani
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors"
            >
              {user ? 'Spremi promjene' : 'Dodaj zaposlenika'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Project Form Modal
function ProjectFormModal({ onClose, onSave }: {
  onClose: () => void;
  onSave: (data: Partial<Project>) => void;
}) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    status: 'planning' as Project['status'],
    startDate: '',
    endDate: '',
    priority: 'medium' as Project['priority'],
    assignedUsers: [] as string[],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Novi projekt</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Naziv projekta</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Opis</label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Početak</label>
              <input
                type="date"
                required
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Završetak</label>
              <input
                type="date"
                required
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Prioritet</label>
            <select
              value={formData.priority}
              onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
            >
              <option value="low">Nizak</option>
              <option value="medium">Srednji</option>
              <option value="high">Visok</option>
            </select>
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 border border-gray-200 rounded-xl font-medium hover:bg-gray-50 transition-colors"
            >
              Odustani
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors"
            >
              Kreiraj projekt
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// News Form Modal
function NewsFormModal({ onClose, onSave }: {
  onClose: () => void;
  onSave: (data: Partial<NewsItem>) => void;
}) {
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    image: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Nova objava</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Naslov</label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Sadržaj</label>
            <textarea
              rows={5}
              required
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">URL slike (opcionalno)</label>
            <input
              type="url"
              value={formData.image}
              onChange={(e) => setFormData({ ...formData, image: e.target.value })}
              placeholder="https://..."
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 border border-gray-200 rounded-xl font-medium hover:bg-gray-50 transition-colors"
            >
              Odustani
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors"
            >
              Objavi
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Dashboard Component
function Dashboard({ user, users, projects, news, onViewUser, onUpdateNews }: {
  user: UserData;
  users: UserData[];
  projects: Project[];
  news: NewsItem[];
  onViewUser: (user: UserData) => void;
  onUpdateNews: (news: NewsItem[]) => void;
}) {
  const myProjects = projects.filter(p => p.assignedUsers.includes(user.id));
  const myTasks = myProjects.flatMap(p => p.tasks.filter(t => t.assignedTo === user.id));

  const toggleLike = (newsId: string) => {
    const updatedNews = news.map(item => {
      if (item.id === newsId) {
        const isLiked = item.likedBy.includes(user.id);
        return {
          ...item,
          likes: isLiked ? item.likes - 1 : item.likes + 1,
          likedBy: isLiked ? item.likedBy.filter(id => id !== user.id) : [...item.likedBy, user.id],
        };
      }
      return item;
    });
    onUpdateNews(updatedNews);
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Dobrodošli, {user.firstName}! 👋</h2>
        <p className="opacity-90">Evo pregleda vaših aktivnosti i obavijesti za danas.</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <QuickStatCard
          title="Moji projekti"
          value={myProjects.length}
          icon={<FolderKanban className="w-5 h-5" />}
          color="bg-blue-500"
        />
        <QuickStatCard
          title="Zadaci"
          value={myTasks.length}
          icon={<ListTodo className="w-5 h-5" />}
          color="bg-green-500"
        />
        <QuickStatCard
          title="Kolega"
          value={users.length}
          icon={<Users className="w-5 h-5" />}
          color="bg-orange-500"
        />
        <QuickStatCard
          title="Novosti"
          value={news.length}
          icon={<Bell className="w-5 h-5" />}
          color="bg-purple-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* News Feed */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="font-semibold text-gray-900">Novosti</h3>
          {news.map((item) => (
            <div key={item.id} className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
              {item.image && (
                <img src={item.image} alt={item.title} className="w-full h-48 object-cover" />
              )}
              <div className="p-5">
                <div className="flex items-center gap-3 mb-3">
                  <img
                    src={users.find(u => u.id === item.authorId)?.avatar || generateAvatar(item.authorName)}
                    alt={item.authorName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-gray-900">{item.authorName}</p>
                    <p className="text-xs text-gray-500">{new Date(item.timestamp).toLocaleDateString('hr-HR')}</p>
                  </div>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                <p className="text-gray-600 text-sm mb-4">{item.content}</p>
                <div className="flex items-center gap-4 pt-4 border-t border-gray-100">
                  <button
                    onClick={() => toggleLike(item.id)}
                    className={cn(
                      "flex items-center gap-1 text-sm transition-colors",
                      item.likedBy.includes(user.id) ? "text-red-500" : "text-gray-500 hover:text-red-500"
                    )}
                  >
                    <Heart className={cn("w-4 h-4", item.likedBy.includes(user.id) && "fill-current")} />
                    {item.likes}
                  </button>
                  <button className="flex items-center gap-1 text-sm text-gray-500 hover:text-indigo-500 transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    {item.comments}
                  </button>
                  <button className="flex items-center gap-1 text-sm text-gray-500 hover:text-indigo-500 transition-colors">
                    <Share2 className="w-4 h-4" />
                    Podijeli
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Upcoming Tasks */}
          <div className="bg-white rounded-2xl border border-gray-200 p-5">
            <h4 className="font-semibold text-gray-900 mb-4">Moji zadaci</h4>
            <div className="space-y-3">
              {myTasks.length === 0 ? (
                <p className="text-gray-500 text-sm">Nemate dodijeljenih zadataka</p>
              ) : (
                myTasks.slice(0, 5).map((task) => (
                  <div key={task.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      task.status === 'done' ? "bg-green-500" :
                      task.status === 'in_progress' ? "bg-yellow-500" : "bg-gray-400"
                    )}></div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900 text-sm">{task.title}</p>
                      <p className="text-xs text-gray-500">Rok: {new Date(task.dueDate).toLocaleDateString('hr-HR')}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Team Members */}
          <div className="bg-white rounded-2xl border border-gray-200 p-5">
            <h4 className="font-semibold text-gray-900 mb-4">Tim</h4>
            <div className="space-y-3">
              {users.filter(u => u.department === user.department && u.id !== user.id).slice(0, 5).map((member) => (
                <button
                  key={member.id}
                  onClick={() => onViewUser(member)}
                  className="flex items-center gap-3 w-full p-2 hover:bg-gray-50 rounded-xl transition-colors text-left"
                >
                  <img src={member.avatar} alt={member.firstName} className="w-10 h-10 rounded-full object-cover" />
                  <div>
                    <p className="font-medium text-gray-900 text-sm">{member.firstName} {member.lastName}</p>
                    <p className="text-xs text-gray-500">{member.position}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="bg-white rounded-2xl border border-gray-200 p-5">
            <h4 className="font-semibold text-gray-900 mb-4">Brzi linkovi</h4>
            <div className="space-y-2">
              <button className="flex items-center gap-3 w-full p-2 text-gray-600 hover:bg-gray-50 rounded-xl transition-colors text-left">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">Kalendar</span>
              </button>
              <button className="flex items-center gap-3 w-full p-2 text-gray-600 hover:bg-gray-50 rounded-xl transition-colors text-left">
                <FileText className="w-4 h-4" />
                <span className="text-sm">Dokumenti</span>
              </button>
              <button className="flex items-center gap-3 w-full p-2 text-gray-600 hover:bg-gray-50 rounded-xl transition-colors text-left">
                <PieChart className="w-4 h-4" />
                <span className="text-sm">Izvještaji</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Profile View Component (Instagram-like)
function ProfileView({ user, currentUser, allUsers, onUpdateUser, isAdmin }: {
  user: UserData;
  currentUser: UserData;
  allUsers: UserData[];
  onUpdateUser: (user: UserData) => void;
  isAdmin: boolean;
}) {
  const [activeTab, setActiveTab] = useState<'posts' | 'about' | 'projects'>('posts');
  const [showPostForm, setShowPostForm] = useState(false);
  const [newPost, setNewPost] = useState({ content: '', image: '' });
  const isOwnProfile = user.id === currentUser.id;
  const isFollowing = currentUser.following.includes(user.id);

  const followers = allUsers.filter(u => u.following.includes(user.id));
  const following = allUsers.filter(u => user.following.includes(u.id));

  const handleCreatePost = () => {
    if (!newPost.content.trim()) return;
    
    const post: Post = {
      id: `post-${Date.now()}`,
      content: newPost.content,
      image: newPost.image || undefined,
      likes: 0,
      comments: [],
      timestamp: new Date().toISOString(),
      likedBy: [],
    };
    
    onUpdateUser({
      ...user,
      posts: [post, ...user.posts],
    });
    
    setNewPost({ content: '', image: '' });
    setShowPostForm(false);
  };

  const toggleFollow = () => {
    if (isFollowing) {
      onUpdateUser({
        ...currentUser,
        following: currentUser.following.filter(id => id !== user.id),
      });
    } else {
      onUpdateUser({
        ...currentUser,
        following: [...currentUser.following, user.id],
      });
    }
  };

  const toggleLikePost = (postId: string) => {
    const updatedPosts = user.posts.map(post => {
      if (post.id === postId) {
        const isLiked = post.likedBy.includes(currentUser.id);
        return {
          ...post,
          likes: isLiked ? post.likes - 1 : post.likes + 1,
          likedBy: isLiked ? post.likedBy.filter(id => id !== currentUser.id) : [...post.likedBy, currentUser.id],
        };
      }
      return post;
    });
    onUpdateUser({ ...user, posts: updatedPosts });
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Cover Image */}
      <div className="relative h-64 rounded-2xl overflow-hidden mb-6">
        <img
          src={user.coverImage}
          alt="Cover"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
      </div>

      {/* Profile Header */}
      <div className="relative px-6 mb-8">
        <div className="flex items-end gap-6 -mt-20">
          <div className="relative">
            <img
              src={user.avatar}
              alt={user.firstName}
              className="w-40 h-40 rounded-full object-cover border-4 border-white shadow-xl"
            />
            {user.status === 'active' && (
              <div className="absolute bottom-2 right-2 w-6 h-6 bg-green-500 border-4 border-white rounded-full"></div>
            )}
          </div>
          <div className="flex-1 pb-4">
            <h2 className="text-3xl font-bold text-gray-900">{user.firstName} {user.lastName}</h2>
            <p className="text-gray-500">{user.position} @ {DEPARTMENTS.find(d => d.id === user.department)?.name}</p>
          </div>
          <div className="flex gap-3 pb-4">
            {!isOwnProfile && (
              <button
                onClick={toggleFollow}
                className={cn(
                  "px-6 py-2 rounded-xl font-medium transition-all",
                  isFollowing
                    ? "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    : "bg-indigo-600 text-white hover:bg-indigo-700"
                )}
              >
                {isFollowing ? 'Pratiš' : 'Prati'}
              </button>
            )}
            {(isOwnProfile || isAdmin) && (
              <button className="px-6 py-2 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
                Uredi profil
              </button>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="flex gap-8 mt-6">
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{user.posts.length}</p>
            <p className="text-gray-500 text-sm">Objava</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{followers.length}</p>
            <p className="text-gray-500 text-sm">Pratitelja</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{following.length}</p>
            <p className="text-gray-500 text-sm">Prati</p>
          </div>
        </div>

        {/* Bio */}
        <p className="mt-4 text-gray-700">{user.bio}</p>

        {/* Info Pills */}
        <div className="flex flex-wrap gap-2 mt-4">
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
            <MapPin className="w-3 h-3" /> {user.residence}
          </span>
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
            <Briefcase className="w-3 h-3" /> {user.position}
          </span>
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
            <Mail className="w-3 h-3" /> {user.email}
          </span>
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
            <Phone className="w-3 h-3" /> {user.phone}
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-t border-gray-200 mt-6">
        <div className="flex gap-8">
          {[
            { id: 'posts', label: 'Objave', icon: Grid3X3 },
            { id: 'about', label: 'O meni', icon: User },
            { id: 'projects', label: 'Projekti', icon: FolderKanban },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 py-4 border-b-2 font-medium transition-colors",
                activeTab === tab.id
                  ? "border-indigo-600 text-indigo-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="py-6">
        {activeTab === 'posts' && (
          <div className="space-y-6">
            {isOwnProfile && (
              <button
                onClick={() => setShowPostForm(true)}
                className="w-full p-4 border-2 border-dashed border-gray-300 rounded-2xl text-gray-500 hover:border-indigo-500 hover:text-indigo-600 transition-colors flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Nova objava
              </button>
            )}
            
            {user.posts.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Camera className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Još nema objava</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {user.posts.map((post) => (
                  <div key={post.id} className="bg-white rounded-2xl border border-gray-200 p-5">
                    <div className="flex items-center gap-3 mb-4">
                      <img src={user.avatar} alt={user.firstName} className="w-10 h-10 rounded-full" />
                      <div>
                        <p className="font-medium text-gray-900">{user.firstName} {user.lastName}</p>
                        <p className="text-xs text-gray-500">{new Date(post.timestamp).toLocaleDateString('hr-HR')}</p>
                      </div>
                    </div>
                    <p className="text-gray-700 mb-4">{post.content}</p>
                    {post.image && (
                      <img src={post.image} alt="Post" className="w-full rounded-xl mb-4" />
                    )}
                    <div className="flex items-center gap-4 pt-4 border-t border-gray-100">
                      <button
                        onClick={() => toggleLikePost(post.id)}
                        className={cn(
                          "flex items-center gap-1 text-sm transition-colors",
                          post.likedBy.includes(currentUser.id) ? "text-red-500" : "text-gray-500 hover:text-red-500"
                        )}
                      >
                        <Heart className={cn("w-4 h-4", post.likedBy.includes(currentUser.id) && "fill-current")} />
                        {post.likes}
                      </button>
                      <button className="flex items-center gap-1 text-sm text-gray-500 hover:text-indigo-500 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                        {post.comments.length}
                      </button>
                      <button className="flex items-center gap-1 text-sm text-gray-500 hover:text-indigo-500 transition-colors">
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'about' && (
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Osobni podaci</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InfoRow label="Ime" value={`${user.firstName} ${user.lastName}`} />
              <InfoRow label="Datum rođenja" value={new Date(user.dateOfBirth).toLocaleDateString('hr-HR')} />
              <InfoRow label="Mjesto rođenja" value={user.placeOfBirth} />
              <InfoRow label="Mjesto bivališta" value={user.residence} />
              <InfoRow label="Email" value={user.email} />
              <InfoRow label="Telefon" value={user.phone} />
              <InfoRow label="Odjel" value={DEPARTMENTS.find(d => d.id === user.department)?.name} />
              <InfoRow label="Pozicija" value={user.position} />
              <InfoRow label="Status" value={user.status === 'active' ? 'Aktivan' : user.status === 'on_leave' ? 'Na odsustvu' : 'Neaktivan'} />
              <InfoRow label="Datum pridruživanja" value={new Date(user.joinDate).toLocaleDateString('hr-HR')} />
            </div>
            
            {isAdmin && (
              <>
                <h3 className="font-semibold text-gray-900 mt-8 mb-4">Dozvole</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {user.permissions.map((perm) => (
                    <div key={perm.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        perm.enabled ? "bg-green-500" : "bg-gray-300"
                      )}></div>
                      <span className="text-sm text-gray-700">{perm.name}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {activeTab === 'projects' && (
          <div className="text-center py-12 text-gray-500">
            <FolderKanban className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Pregled projekata uskoro dostupan</p>
          </div>
        )}
      </div>

      {/* Create Post Modal */}
      {showPostForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900">Nova objava</h3>
              <button onClick={() => setShowPostForm(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <textarea
                rows={4}
                placeholder="Što vam je na umu?"
                value={newPost.content}
                onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none resize-none"
              />
              <input
                type="url"
                placeholder="URL slike (opcionalno)"
                value={newPost.image}
                onChange={(e) => setNewPost({ ...newPost, image: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
              />
              <div className="flex gap-3">
                <button
                  onClick={() => setShowPostForm(false)}
                  className="flex-1 py-3 border border-gray-200 rounded-xl font-medium hover:bg-gray-50 transition-colors"
                >
                  Odustani
                </button>
                <button
                  onClick={handleCreatePost}
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors"
                >
                  Objavi
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Projects View Component
function ProjectsView({ projects, users, currentUser, onUpdateProjects }: {
  projects: Project[];
  users: UserData[];
  currentUser: UserData;
  onUpdateProjects: (projects: Project[]) => void;
}) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filter, setFilter] = useState<'all' | 'my'>('all');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filteredProjects = filter === 'my'
    ? projects.filter(p => p.assignedUsers.includes(currentUser.id))
    : projects;

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={cn(
              "px-4 py-2 rounded-xl font-medium transition-colors",
              filter === 'all' ? "bg-indigo-600 text-white" : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"
            )}
          >
            Svi projekti
          </button>
          <button
            onClick={() => setFilter('my')}
            className={cn(
              "px-4 py-2 rounded-xl font-medium transition-colors",
              filter === 'my' ? "bg-indigo-600 text-white" : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"
            )}
          >
            Moji projekti
          </button>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode('grid')}
            className={cn(
              "p-2 rounded-lg transition-colors",
              viewMode === 'grid' ? "bg-indigo-100 text-indigo-600" : "text-gray-400 hover:bg-gray-100"
            )}
          >
            <Grid3X3 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={cn(
              "p-2 rounded-lg transition-colors",
              viewMode === 'list' ? "bg-indigo-100 text-indigo-600" : "text-gray-400 hover:bg-gray-100"
            )}
          >
            <TableIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Projects Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => setSelectedProject(project)}
              className="bg-white rounded-2xl border border-gray-200 p-5 cursor-pointer hover:shadow-lg transition-shadow"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h4 className="font-semibold text-gray-900">{project.name}</h4>
                  <p className="text-sm text-gray-500 mt-1 line-clamp-2">{project.description}</p>
                </div>
                <ProjectStatusBadge status={project.status} />
              </div>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-500">Napredak</span>
                    <span className="font-medium text-gray-900">{project.progress}%</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-500 rounded-full transition-all"
                      style={{ width: `${project.progress}%` }}
                    ></div>
                  </div>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Zadaci</span>
                  <span className="font-medium text-gray-900">{project.tasks.filter(t => t.status === 'done').length}/{project.tasks.length}</span>
                </div>
                <div className="flex -space-x-2 pt-2">
                  {project.assignedUsers.slice(0, 3).map((userId) => {
                    const user = users.find(u => u.id === userId);
                    return user ? (
                      <img
                        key={userId}
                        src={user.avatar}
                        alt={user.firstName}
                        className="w-8 h-8 rounded-full border-2 border-white object-cover"
                      />
                    ) : null;
                  })}
                  {project.assignedUsers.length > 3 && (
                    <div className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white flex items-center justify-center text-xs font-medium text-gray-600">
                      +{project.assignedUsers.length - 3}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Projekt</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Napredak</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Prioritet</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Rok</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredProjects.map((project) => (
                <tr
                  key={project.id}
                  onClick={() => setSelectedProject(project)}
                  className="hover:bg-gray-50 cursor-pointer"
                >
                  <td className="py-3 px-4">
                    <p className="font-medium text-gray-900">{project.name}</p>
                    <p className="text-sm text-gray-500">{project.description.slice(0, 50)}...</p>
                  </td>
                  <td className="py-3 px-4"><ProjectStatusBadge status={project.status} /></td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 rounded-full"
                          style={{ width: `${project.progress}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">{project.progress}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4"><PriorityBadge priority={project.priority} /></td>
                  <td className="py-3 px-4 text-gray-600">{new Date(project.endDate).toLocaleDateString('hr-HR')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Project Detail Modal */}
      {selectedProject && (
        <ProjectDetailModal
          project={selectedProject}
          currentUser={currentUser}
          onClose={() => setSelectedProject(null)}
          onUpdate={(updatedProject) => {
            onUpdateProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
            setSelectedProject(updatedProject);
          }}
        />
      )}
    </div>
  );
}

// Project Detail Modal
function ProjectDetailModal({ project, currentUser, onClose, onUpdate }: {
  project: Project;
  currentUser: UserData;
  onClose: () => void;
  onUpdate: (project: Project) => void;
}) {
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', description: '', dueDate: '', priority: 'medium' as Task['priority'] });

  const handleAddTask = () => {
    if (!newTask.title.trim()) return;
    
    const task: Task = {
      id: `task-${Date.now()}`,
      title: newTask.title,
      description: newTask.description,
      status: 'todo',
      assignedTo: currentUser.id,
      dueDate: newTask.dueDate,
      priority: newTask.priority,
    };
    
    onUpdate({
      ...project,
      tasks: [...project.tasks, task],
    });
    
    setNewTask({ title: '', description: '', dueDate: '', priority: 'medium' });
    setShowTaskForm(false);
  };

  const toggleTaskStatus = (taskId: string) => {
    onUpdate({
      ...project,
      tasks: project.tasks.map(t => {
        if (t.id === taskId) {
          const statuses: Task['status'][] = ['todo', 'in_progress', 'done'];
          const currentIndex = statuses.indexOf(t.status);
          return { ...t, status: statuses[(currentIndex + 1) % statuses.length] };
        }
        return t;
      }),
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200 flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold text-gray-900">{project.name}</h3>
            <p className="text-gray-500 mt-1">{project.description}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-500 mb-1">Status</p>
              <ProjectStatusBadge status={project.status} />
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-500 mb-1">Prioritet</p>
              <PriorityBadge priority={project.priority} />
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-500 mb-1">Početak</p>
              <p className="font-medium text-gray-900">{new Date(project.startDate).toLocaleDateString('hr-HR')}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm text-gray-500 mb-1">Završetak</p>
              <p className="font-medium text-gray-900">{new Date(project.endDate).toLocaleDateString('hr-HR')}</p>
            </div>
          </div>

          {/* Progress */}
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Napredak projekta</span>
              <span className="font-medium text-gray-900">{project.progress}%</span>
            </div>
            <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-500 rounded-full transition-all"
                style={{ width: `${project.progress}%` }}
              ></div>
            </div>
          </div>

          {/* Tasks */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h4 className="font-semibold text-gray-900">Zadaci ({project.tasks.length})</h4>
              <button
                onClick={() => setShowTaskForm(true)}
                className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-700 font-medium"
              >
                <Plus className="w-4 h-4" />
                Dodaj zadatak
              </button>
            </div>
            <div className="space-y-3">
              {project.tasks.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Nema zadataka</p>
              ) : (
                project.tasks.map((task) => (
                  <div key={task.id} className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                    <button
                      onClick={() => toggleTaskStatus(task.id)}
                      className={cn(
                        "w-5 h-5 rounded border-2 flex items-center justify-center transition-colors",
                        task.status === 'done'
                          ? "bg-green-500 border-green-500 text-white"
                          : task.status === 'in_progress'
                          ? "bg-yellow-500 border-yellow-500 text-white"
                          : "border-gray-300 hover:border-indigo-500"
                      )}
                    >
                      {task.status === 'done' && <CheckCircle className="w-3 h-3" />}
                      {task.status === 'in_progress' && <Clock className="w-3 h-3" />}
                    </button>
                    <div className="flex-1">
                      <p className={cn(
                        "font-medium",
                        task.status === 'done' ? "text-gray-400 line-through" : "text-gray-900"
                      )}>{task.title}</p>
                      <p className="text-sm text-gray-500">{task.description}</p>
                    </div>
                    <PriorityBadge priority={task.priority} />
                    <span className="text-xs text-gray-500">{new Date(task.dueDate).toLocaleDateString('hr-HR')}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Add Task Modal */}
        {showTaskForm && (
          <div className="p-6 border-t border-gray-200 bg-gray-50">
            <h4 className="font-semibold text-gray-900 mb-4">Novi zadatak</h4>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Naslov zadatka"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
              />
              <textarea
                placeholder="Opis zadatka"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none resize-none"
                rows={2}
              />
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="date"
                  value={newTask.dueDate}
                  onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                  className="px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
                />
                <select
                  value={newTask.priority}
                  onChange={(e) => setNewTask({ ...newTask, priority: e.target.value as any })}
                  className="px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
                >
                  <option value="low">Nizak prioritet</option>
                  <option value="medium">Srednji prioritet</option>
                  <option value="high">Visok prioritet</option>
                </select>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowTaskForm(false)}
                  className="flex-1 py-2 border border-gray-200 rounded-lg hover:bg-white transition-colors"
                >
                  Odustani
                </button>
                <button
                  onClick={handleAddTask}
                  className="flex-1 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Dodaj
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// News View Component
function NewsView({ news, users, currentUser, onUpdateNews }: {
  news: NewsItem[];
  users: UserData[];
  currentUser: UserData;
  onUpdateNews: (news: NewsItem[]) => void;
}) {
  const toggleLike = (newsId: string) => {
    const updatedNews = news.map(item => {
      if (item.id === newsId) {
        const isLiked = item.likedBy.includes(currentUser.id);
        return {
          ...item,
          likes: isLiked ? item.likes - 1 : item.likes + 1,
          likedBy: isLiked ? item.likedBy.filter(id => id !== currentUser.id) : [...item.likedBy, currentUser.id],
        };
      }
      return item;
    });
    onUpdateNews(updatedNews);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">📢 Firma Novosti</h2>
        <p className="opacity-90">Budite u toku s najnovijim zbivanjima u našoj firmi.</p>
      </div>

      {news.map((item) => (
        <div key={item.id} className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
          {item.image && (
            <img src={item.image} alt={item.title} className="w-full h-64 object-cover" />
          )}
          <div className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <img
                src={users.find(u => u.id === item.authorId)?.avatar || generateAvatar(item.authorName)}
                alt={item.authorName}
                className="w-12 h-12 rounded-full object-cover"
              />
              <div>
                <p className="font-semibold text-gray-900">{item.authorName}</p>
                <p className="text-sm text-gray-500">{new Date(item.timestamp).toLocaleDateString('hr-HR', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
              </div>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
            <p className="text-gray-700 leading-relaxed">{item.content}</p>
            <div className="flex items-center gap-6 pt-6 mt-6 border-t border-gray-100">
              <button
                onClick={() => toggleLike(item.id)}
                className={cn(
                  "flex items-center gap-2 transition-colors",
                  item.likedBy.includes(currentUser.id) ? "text-red-500" : "text-gray-500 hover:text-red-500"
                )}
              >
                <Heart className={cn("w-5 h-5", item.likedBy.includes(currentUser.id) && "fill-current")} />
                <span className="font-medium">{item.likes} sviđanja</span>
              </button>
              <button className="flex items-center gap-2 text-gray-500 hover:text-indigo-500 transition-colors">
                <MessageCircle className="w-5 h-5" />
                <span className="font-medium">{item.comments} komentara</span>
              </button>
              <button className="flex items-center gap-2 text-gray-500 hover:text-indigo-500 transition-colors">
                <Share2 className="w-5 h-5" />
                <span className="font-medium">Podijeli</span>
              </button>
              <button className="flex items-center gap-2 text-gray-500 hover:text-indigo-500 transition-colors ml-auto">
                <Bookmark className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// Users View Component
function UsersView({ users, onViewUser }: {
  users: UserData[];
  onViewUser: (user: UserData) => void;
}) {
  const [search, setSearch] = useState('');
  const [filterDept, setFilterDept] = useState<string>('all');

  const filteredUsers = users.filter(user => {
    const matchesSearch = `${user.firstName} ${user.lastName} ${user.position}`.toLowerCase().includes(search.toLowerCase());
    const matchesDept = filterDept === 'all' || user.department === filterDept;
    return matchesSearch && matchesDept;
  });

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pretraži zaposlenike..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
          />
        </div>
        <select
          value={filterDept}
          onChange={(e) => setFilterDept(e.target.value)}
          className="px-4 py-2 border border-gray-200 rounded-xl focus:border-indigo-500 outline-none"
        >
          <option value="all">Svi odjeli</option>
          {DEPARTMENTS.map(dept => (
            <option key={dept.id} value={dept.id}>{dept.name}</option>
          ))}
        </select>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredUsers.map((user) => (
          <button
            key={user.id}
            onClick={() => onViewUser(user)}
            className="bg-white rounded-2xl border border-gray-200 p-5 text-left hover:shadow-lg transition-all group"
          >
            <div className="relative mb-4">
              <img
                src={user.avatar}
                alt={user.firstName}
                className="w-20 h-20 rounded-full object-cover mx-auto group-hover:scale-105 transition-transform"
              />
              <div className={cn(
                "absolute bottom-0 right-1/3 w-4 h-4 rounded-full border-2 border-white",
                user.status === 'active' ? "bg-green-500" :
                user.status === 'on_leave' ? "bg-yellow-500" : "bg-gray-400"
              )}></div>
            </div>
            <div className="text-center">
              <h4 className="font-semibold text-gray-900">{user.firstName} {user.lastName}</h4>
              <p className="text-sm text-gray-500">{user.position}</p>
              <span className="inline-block mt-2 px-3 py-1 bg-gray-100 rounded-full text-xs text-gray-600">
                {DEPARTMENTS.find(d => d.id === user.department)?.name}
              </span>
            </div>
            <div className="flex justify-center gap-4 mt-4 pt-4 border-t border-gray-100">
              <div className="text-center">
                <p className="font-bold text-gray-900">{user.posts.length}</p>
                <p className="text-xs text-gray-500">Objava</p>
              </div>
              <div className="text-center">
                <p className="font-bold text-gray-900">{user.following.length}</p>
                <p className="text-xs text-gray-500">Prati</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// Settings View Component
function SettingsView({ user, onUpdateUser }: {
  user: UserData;
  onUpdateUser: (user: UserData) => void;
}) {
  const [formData, setFormData] = useState({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    phone: user.phone,
    bio: user.bio,
    residence: user.residence,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({ ...user, ...formData });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl border border-gray-200 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Postavke profila</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Ime</label>
              <input
                type="text"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Prezime</label>
              <input
                type="text"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mjesto bivališta</label>
            <input
              type="text"
              value={formData.residence}
              onChange={(e) => setFormData({ ...formData, residence: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Biografija</label>
            <textarea
              rows={4}
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:border-indigo-500 outline-none resize-none"
            />
          </div>
          <button
            type="submit"
            className="w-full py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors"
          >
            Spremi promjene
          </button>
        </form>
      </div>
    </div>
  );
}

// Helper Components
function StatCard({ title, value, subtitle, icon, color }: {
  title: string;
  value: number;
  subtitle?: string;
  icon: React.ReactNode;
  color: string;
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-gray-500 text-sm">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mt-1">{value}</p>
          {subtitle && <p className="text-sm text-gray-400 mt-1">{subtitle}</p>}
        </div>
        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center text-white", color)}>
          {icon}
        </div>
      </div>
    </div>
  );
}

function QuickStatCard({ title, value, icon, color }: {
  title: string;
  value: number;
  icon: React.ReactNode;
  color: string;
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center gap-3">
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center text-white", color)}>
          {icon}
        </div>
        <div>
          <p className="text-gray-500 text-xs">{title}</p>
          <p className="text-xl font-bold text-gray-900">{value}</p>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: UserData['status'] }) {
  const colors = {
    active: 'bg-green-100 text-green-700',
    inactive: 'bg-gray-100 text-gray-600',
    on_leave: 'bg-yellow-100 text-yellow-700',
  };
  const labels = {
    active: 'Aktivan',
    inactive: 'Neaktivan',
    on_leave: 'Na odsustvu',
  };
  return (
    <span className={cn("px-2 py-1 rounded-lg text-xs font-medium", colors[status])}>
      {labels[status]}
    </span>
  );
}

function ProjectStatusBadge({ status }: { status: Project['status'] }) {
  const colors = {
    planning: 'bg-blue-100 text-blue-700',
    in_progress: 'bg-yellow-100 text-yellow-700',
    completed: 'bg-green-100 text-green-700',
    on_hold: 'bg-red-100 text-red-700',
  };
  const labels = {
    planning: 'Planiranje',
    in_progress: 'U tijeku',
    completed: 'Završen',
    on_hold: 'Pauziran',
  };
  return (
    <span className={cn("px-2 py-1 rounded-lg text-xs font-medium", colors[status])}>
      {labels[status]}
    </span>
  );
}

function PriorityBadge({ priority }: { priority: 'low' | 'medium' | 'high' }) {
  const colors = {
    low: 'bg-gray-100 text-gray-600',
    medium: 'bg-orange-100 text-orange-700',
    high: 'bg-red-100 text-red-700',
  };
  const labels = {
    low: 'Nizak',
    medium: 'Srednji',
    high: 'Visok',
  };
  return (
    <span className={cn("px-2 py-1 rounded-lg text-xs font-medium", colors[priority])}>
      {labels[priority]}
    </span>
  );
}

function InfoRow({ label, value }: { label: string; value?: string }) {
  return (
    <div className="p-3 bg-gray-50 rounded-xl">
      <p className="text-xs text-gray-500 mb-1">{label}</p>
      <p className="font-medium text-gray-900">{value || '-'}</p>
    </div>
  );
}
